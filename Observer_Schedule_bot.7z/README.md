RIGT is a telegram bot for automatic schedule sending.
